<?php
include 'db.php';
$name = $_POST['name'];
$department = $_POST['department'];
$salary = $_POST['salary'];
$conn->query("INSERT INTO employees (name, department, salary) VALUES ('$name','$department','$salary')");
echo json_encode(["success"=>true]);
?>