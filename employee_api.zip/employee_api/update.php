<?php
include 'db.php';
$id = $_POST['id'];
$name = $_POST['name'];
$department = $_POST['department'];
$salary = $_POST['salary'];
$conn->query("UPDATE employees SET name='$name', department='$department', salary='$salary' WHERE id=$id");
echo json_encode(["success"=>true]);
?>