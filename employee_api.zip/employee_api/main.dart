import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: EmployeePage(),
    );
  }
}

class EmployeePage extends StatefulWidget {
  const EmployeePage({super.key});
  @override
  State<EmployeePage> createState() => _EmployeePageState();
}

class _EmployeePageState extends State<EmployeePage> {
  final nameController = TextEditingController();
  final deptController = TextEditingController();
  final salaryController = TextEditingController();

  List employees = [];
  int? selectedId;

  final String baseUrl = "http://10.0.2.2/employee_api";

  @override
  void initState() {
    super.initState();
    fetchEmployees();
  }

  Future fetchEmployees() async {
    final response = await http.get(Uri.parse("$baseUrl/fetch.php"));
    setState(() {
      employees = jsonDecode(response.body);
    });
  }

  Future addEmployee() async {
    await http.post(Uri.parse("$baseUrl/insert.php"), body: {
      'name': nameController.text,
      'department': deptController.text,
      'salary': salaryController.text,
    });
    clear();
    fetchEmployees();
  }

  Future updateEmployee() async {
    await http.post(Uri.parse("$baseUrl/update.php"), body: {
      'id': selectedId.toString(),
      'name': nameController.text,
      'department': deptController.text,
      'salary': salaryController.text,
    });
    clear();
    fetchEmployees();
  }

  Future deleteEmployee(String id) async {
    await http.post(Uri.parse("$baseUrl/delete.php"), body: {'id': id});
    fetchEmployees();
  }

  void clear() {
    nameController.clear();
    deptController.clear();
    salaryController.clear();
    selectedId = null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Employee CRUD")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: nameController, decoration: const InputDecoration(labelText: "Name")),
            TextField(controller: deptController, decoration: const InputDecoration(labelText: "Department")),
            TextField(controller: salaryController, decoration: const InputDecoration(labelText: "Salary"), keyboardType: TextInputType.number),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: selectedId == null ? addEmployee : updateEmployee,
              child: Text(selectedId == null ? "Add" : "Update"),
            ),
            const Divider(),
            Expanded(
              child: ListView.builder(
                itemCount: employees.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(employees[index]['name']),
                    subtitle: Text("${employees[index]['department']} | ₹${employees[index]['salary']}"),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () {
                            setState(() {
                              selectedId = int.parse(employees[index]['id']);
                              nameController.text = employees[index]['name'];
                              deptController.text = employees[index]['department'];
                              salaryController.text = employees[index]['salary'].toString();
                            });
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () {
                            deleteEmployee(employees[index]['id']);
                          },
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
